package jKalman;

import java.awt.*;
import javax.swing.*;

/** Panel to hold input textfields. **/
public class InputsPanel extends JPanel {
	JTextField fTextfieldTop;

	/** Constructor builds panel with labels and text fields. **/
	InputsPanel(String label_str_top, String init_top) {

		// Set the layout with 2 rows by 2 columns
		setLayout(new GridLayout(1, 2));

		// Create two text fields with the initial values
		fTextfieldTop = new JTextField(init_top);
		// fTextfieldTop.setSize(300, 20);

		// Create the first label and right justify the text
		JLabel label_top = new JLabel(label_str_top, SwingConstants.RIGHT);

		// Insert the label and textfield into the top grid row
		add(label_top);
		add(fTextfieldTop);

	} // ctor

}// class InputsPanel