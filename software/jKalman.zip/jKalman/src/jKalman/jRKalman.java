package jKalman;

import static org.math.array.DoubleArray.identity;
import static org.math.array.DoubleArray.transpose;
import static org.math.array.LinearAlgebra.inverse;
import static org.math.array.LinearAlgebra.minus;
import static org.math.array.LinearAlgebra.plus;
import static org.math.array.LinearAlgebra.times;

import static org.math.io.files.ASCIIFile.*;
import static org.math.io.parser.ArrayString.*;

import static org.math.array.DoubleArray.*;
import static org.math.array.LinearAlgebra.*;

import javax.swing.*;

import java.io.*;
import org.math.plot.Plot2DPanel;
import org.math.plot.Plot3DPanel;

import java.awt.*;
import java.awt.event.*;

/*
 *  String str1 = fInputsPanel.fTextfieldTop.getText ();
 *  val1 = Double.parseDouble (str1).getText ();
 */
/**
 * 
 * @author Mykola Novik java -Dsun.java2d.pmoffscreen=false
 */
// implements ActionListener
public class jRKalman {
	final static boolean shouldFill = true;
	final static boolean shouldWeightX = true;
	final static boolean RIGHT_TO_LEFT = false;

	// time variables
	static double simTime = 1000;
	static double stepTime = 1;
	static double[] t = FlightPathGen.loadTimeArray(simTime, stepTime);
	// Start coordinates
	static double Phi0 = 55 * (Math.PI / 180);
	static double Lam0 = 30 * (Math.PI / 180);
	static double H0 = 5000;
	// Period of trajectory
	static double TPhi = 600;
	static double TLam = 600;
	static double TH = 600;
	// linear part of eq
	static double kPhi = 0;
	static double kLam = 0.00004;
	// delta Phi
	static double deltaPhi = 0.004;
	static double deltaLam = 0;
	static double deltaH = H0;
	// delta phase
	static double ddeltaPhi = 0;
	static double ddeltaLam = 0;
	static double ddeltaH = 0;

	static double WPhi = 2 * Math.PI / TPhi;
	static double WLam = 2 * Math.PI / TLam;
	static double WH = 2 * Math.PI / TH;

	// store Data
	static double[] Phi;
	static double[] Lam;
	static double[] H;
	static double[] Pitch;
	static double[] Yaw;
	static double[] Roll;
	static double[] VE;
	static double[] VN;
	static double[] VH;
	static double[] AE;
	static double[] AN;
	static double[] AH;
	//

	FlightPathGen FP;
	static FlightPropPanel FPset;
	// ///////////////////////////////////////
	// GUI
	static JFrame frame;
	// PLOTS
	static Plot2DPanel plot11;
	static Plot2DPanel plot12;
	static Plot2DPanel plot13;

	static Plot2DPanel plot21;
	static Plot2DPanel plot22;
	static Plot2DPanel plot23;

	static Plot2DPanel plot31;
	static Plot2DPanel plot32;
	static Plot2DPanel plot33;

	static Plot2DPanel plot41;
	static Plot2DPanel plot42;
	static Plot2DPanel plot43;

	static Plot2DPanel plot51;
	static Plot2DPanel plot52;
	static Plot2DPanel plot53;

	static Plot3DPanel path3d;
	static Plot2DPanel pathPitch;
	static Plot2DPanel pathYaw;
	static Plot2DPanel pathRoll;

	static double[][] XP;
	static double[][] XR;
	static double[][] XD;

	static public void InitPlots() {
		// Plots for TAB 1
		plot11 = new Plot2DPanel();
		plot11.addLegend("SOUTH");
		plot12 = new Plot2DPanel();
		plot12.addLegend("SOUTH");
		plot13 = new Plot2DPanel();
		plot13.addLegend("SOUTH");

		plot21 = new Plot2DPanel();
		plot21.addLegend("SOUTH");
		plot22 = new Plot2DPanel();
		plot22.addLegend("SOUTH");
		plot23 = new Plot2DPanel();
		plot23.addLegend("SOUTH");

		plot31 = new Plot2DPanel();
		plot31.addLegend("SOUTH");
		plot32 = new Plot2DPanel();
		plot32.addLegend("SOUTH");
		plot33 = new Plot2DPanel();
		plot33.addLegend("SOUTH");

		plot41 = new Plot2DPanel();
		plot41.addLegend("SOUTH");
		plot42 = new Plot2DPanel();
		plot42.addLegend("SOUTH");
		plot43 = new Plot2DPanel();
		plot43.addLegend("SOUTH");

		plot51 = new Plot2DPanel();
		plot51.addLegend("SOUTH");
		plot52 = new Plot2DPanel();
		plot52.addLegend("SOUTH");
		plot53 = new Plot2DPanel();
		plot53.addLegend("SOUTH");

		pathPitch = new Plot2DPanel();
		pathPitch.addLegend("SOUTH");
		pathPitch.setAxisLabel(0, "t, s");
		pathPitch.setAxisLabel(1, "Pitch, DEG");

		pathYaw = new Plot2DPanel();
		pathYaw.addLegend("SOUTH");
		pathYaw.setAxisLabel(0, "t, s");
		pathYaw.setAxisLabel(1, "Yaw, DEG");

		pathRoll = new Plot2DPanel();
		pathRoll.addLegend("SOUTH");
		pathRoll.setAxisLabel(0, "t, s");
		pathRoll.setAxisLabel(1, "Roll, DEG");

		// 3D PLOT
		path3d = new Plot3DPanel();
		path3d.addLegend("SOUTH");
		path3d.setAxisLabel(0, "Phi, DEG");
		path3d.setAxisLabel(1, "Lam, DEG");
		path3d.setAxisLabel(2, "H, m");
	}
	
	static public void ClearAllPlots()
	{
		plot11.removeAllPlots();
		plot12.removeAllPlots();
		plot13.removeAllPlots();
		plot21.removeAllPlots();
		plot22.removeAllPlots();
		plot23.removeAllPlots();
		plot31.removeAllPlots();
		plot32.removeAllPlots();
		plot33.removeAllPlots();
		plot41.removeAllPlots();
		plot42.removeAllPlots();
		plot43.removeAllPlots();
		plot51.removeAllPlots();
		plot52.removeAllPlots();
		plot53.removeAllPlots();
		pathPitch.removeAllPlots();
		pathYaw.removeAllPlots();
		pathRoll.removeAllPlots();
		// 3D PLOT
		path3d.removeAllPlots();

		
	}
	static protected JPanel createInnerPanel31(String text) {
		JPanel jplPanel = new JPanel();
		// JLabel jlbDisplay = new JLabel(text);
		// jlbDisplay.setHorizontalAlignment(JLabel.CENTER);
		jplPanel.setLayout(new GridLayout(3, 1));
		// jplPanel.add(jlbDisplay);
		return jplPanel;
	}

	static protected JPanel createInnerPanel11(String text) {
		JPanel jplPanel = new JPanel();

		// JLabel jlbDisplay = new JLabel(text);
		// jlbDisplay.setHorizontalAlignment(JLabel.CENTER);
		jplPanel.setLayout(new GridLayout(1, 1));
		// jplPanel.add(jlbDisplay);
		return jplPanel;
	}

	public static void addComponentsToPane(Container pane) {
		if (RIGHT_TO_LEFT) {
			pane.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		}
		// Icons set
		ImageIcon icon1 = new ImageIcon("pics/1.png");
		ImageIcon icon2 = new ImageIcon("pics/2.png");
		ImageIcon icon3 = new ImageIcon("pics/3.png");
		ImageIcon icon4 = new ImageIcon("pics/4.png");
		ImageIcon icon5 = new ImageIcon("pics/5.png");

		// Math Plot 1
		// double[] x1 = { 1, 2, 3, 4, 5, 6, 7, 8 };
		// double[] y1 = { 1, 4, 9, 16, 25, 36, 49, 64 };

		InitPlots();

		// Create Tabs
		JTabbedPane TabPanel = new JTabbedPane();

		JPanel jplInnerPanel1 = createInnerPanel31("");
		TabPanel.addTab("R", icon1, jplInnerPanel1, "Tab 1");
		jplInnerPanel1.add(plot11);
		jplInnerPanel1.add(plot12);
		jplInnerPanel1.add(plot13);

		JPanel jplInnerPanel2 = createInnerPanel31("");
		TabPanel.addTab("V", icon2, jplInnerPanel2);
		jplInnerPanel2.add(plot21);
		jplInnerPanel2.add(plot22);
		jplInnerPanel2.add(plot23);

		JPanel jplInnerPanel3 = createInnerPanel31("");
		TabPanel.addTab("Alpha", icon3, jplInnerPanel3, "Tab 3");
		jplInnerPanel3.add(plot31);
		jplInnerPanel3.add(plot32);
		jplInnerPanel3.add(plot33);

		JPanel jplInnerPanel4 = createInnerPanel31("");
		TabPanel.addTab("Gyro", icon4, jplInnerPanel4);
		jplInnerPanel4.add(plot41);
		jplInnerPanel4.add(plot42);
		jplInnerPanel4.add(plot43);

		JPanel jplInnerPanel5 = createInnerPanel31("");
		TabPanel.addTab("Acc", icon5, jplInnerPanel5);
		jplInnerPanel5.add(plot51);
		jplInnerPanel5.add(plot52);
		jplInnerPanel5.add(plot53);

		JPanel jplInnerPanel6 = createInnerPanel11("");
		TabPanel.addTab("3D-Path", icon5, jplInnerPanel6);
		// TabPanel.setSelectedIndex(0);
		jplInnerPanel6.add(path3d);

		JPanel jplInnerPanel7 = createInnerPanel31("");
		TabPanel.addTab("Pitch/Yaw/Roll", icon5, jplInnerPanel7);

		jplInnerPanel7.add(pathPitch);
		jplInnerPanel7.add(pathYaw);
		jplInnerPanel7.add(pathRoll);

		// Create menu
		JMenuBar mainMenuBar = new JMenuBar();
		JMenu menuFile = new JMenu("File");
		JMenuItem pTextMenuItem1 = new JMenuItem("Compute Flight Path",
				KeyEvent.VK_T);
		JMenuItem FileMenuItemOpen = new JMenuItem("Open Data", KeyEvent.VK_T);
		JMenuItem FileMenuItemSave = new JMenuItem("Save Data", KeyEvent.VK_T);
		JMenuItem FileMenuItemQuit = new JMenuItem("Quit", KeyEvent.VK_T);
		pTextMenuItem1.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent me) {
				GenerateTrajectory();

			};

		});

		FileMenuItemQuit.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent me) {
				System.exit(0);
			};
		});
		FileMenuItemOpen.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent me) {
				//JFileChooser fc = new JFileChooser();
				//fc.showOpenDialog(frame);
				//fc.setVisible(true);
				SetDialog f = new SetDialog(frame);
				f.show();
			};
		});
		FileMenuItemSave.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent me) {
				JFileChooser fc = new JFileChooser();
				fc.showSaveDialog(frame);
				fc.setVisible(true);
			};
		});

		// pTextMenuItem3.addActionListener();

		menuFile.add(pTextMenuItem1);
		menuFile.add(FileMenuItemOpen);
		menuFile.add(FileMenuItemSave);
		menuFile.add(FileMenuItemQuit);

		JMenu menuView = new JMenu("View");
		JMenu menuHelp = new JMenu("Help?");
		mainMenuBar.add(menuFile);
		mainMenuBar.add(menuView);
		mainMenuBar.add(menuHelp);

		// JButton button;
		JButton CalcButton = new JButton("FIRE!");
		CalcButton.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent me) {
				GenerateTrajectory();

			};
		});
		JButton ClearButton = new JButton("CLEAR ALL!");
		ClearButton.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent me) {
				ClearAllPlots();

			};
		});
		
		

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		// c.fill = GridBagConstraints.HORIZONTAL;

		if (shouldFill) {
			// natural height, maximum width
			c.fill = GridBagConstraints.BOTH;
			// c.fill = GridBagConstraints.VERTICAL;
		}
		// button = new JButton("Button 1");
		if (shouldWeightX) {
			c.weightx = 0.3;
		}

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 2;
		c.weightx = 0;
		pane.add(mainMenuBar, c);

		// Input Panel
		double[] PropData = { simTime, stepTime, Phi0, Lam0, H0, TPhi, TLam,
				TH, deltaPhi, deltaLam, deltaH, ddeltaPhi, ddeltaLam, ddeltaH,
				kPhi, kLam };
		FPset = new FlightPropPanel(PropData);
		// InputsPanel fInputsPanel1 = new InputsPanel("time, sec ", "100");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.weightx = 0;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 1;
		pane.add(FPset, c);

		InputsPanel fInputsPanel2 = new InputsPanel("Step, sec ", "1");
		// c.fill = GridBagConstraints.HORIZONTAL;
		c.weightx = 0;
		c.gridx = 0;
		c.gridy = 1;
		pane.add(fInputsPanel2, c);

		// c.fill = GridBagConstraints.HORIZONTAL;
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 1;
		c.gridy = 1;
		// c.gridwidth = 1;
		c.gridheight = 2;
		c.weightx = 1;
		c.weighty = 1;
		pane.add(TabPanel, c);

		c.fill = GridBagConstraints.NONE;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		c.weightx = 0;
		c.gridx = 0;
		c.gridy = 2;
		pane.add(CalcButton, c);
		
		c.fill = GridBagConstraints.NONE;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		c.weightx = 0;
		c.gridx = 1;
		c.gridy = 3;
		pane.add(ClearButton, c);


	}


	public static void PlotKalmanXP() {
		
		 double[] DRE = CopyRowArr(XP, 0, t.length); 
		 double[] DRN =	 CopyRowArr(XP, 1, t.length); 
		 double[] DRH = CopyRowArr(XR, 2, t.length);
		 plot11.addLinePlot("RE", t,DRE); 
		 plot12.addLinePlot("RN", t,DRN); 
		 plot13.addLinePlot("RH", t,DRH);
		 
		 double[] DVE = CopyRowArr(XP, 3, t.length); 
		 double[] DVN = CopyRowArr(XP, 4, t.length); 
		 double[] DVH = CopyRowArr(XP, 5, t.length); 
		 plot21.addLinePlot("dVE", t,DVE);
		 plot22.addLinePlot("dVN", t,DVN); 
		 plot23.addLinePlot("dVH", t,DVH);
		 
		 double[] AlE = CopyRowArr(XP, 6, t.length); 
		 double[] AlN = CopyRowArr(XP, 7, t.length); 
		 double[] AlH = CopyRowArr(XP, 8, t.length); 
		 plot31.addLinePlot("AlE", t,AlE);
		 plot32.addLinePlot("AlN", t,AlN); 
		 plot33.addLinePlot("AlH", t,AlH);
		 
		 			 
		double[] GyE = CopyRowArr(XP, 9, t.length); 
		double[] GyN =CopyRowArr(XP, 10, t.length); 
		double[] GyH = CopyRowArr(XP, 11,t.length); 
		plot41.addLinePlot("GyE", t,GyE);
		plot42.addLinePlot("GyN", t,GyN); 
		plot43.addLinePlot("GyH", t,GyH);
			 
		double[] AccE = CopyRowArr(XP, 12, t.length); 
		double[] AccN =CopyRowArr(XP, 13, t.length); 
		double[] AccH = CopyRowArr(XP, 14,t.length); 
		plot51.addLinePlot("AccE", t,AccE);
		plot52.addLinePlot("AccN", t,AccN); 
		plot53.addLinePlot("AccH", t,AccH);	 
		 
		 	
		// double[][] Xdiff = minus(XP,XR);
		// System.out.println("RE = \n" + printDoubleArray(RE));
		// double[] RE = CopyRowArr(Xdiff, 1, FP.t.length);

	}
	public static void PlotKalmanXR() {
		
		 double[] DRE = CopyRowArr(XR, 0, t.length); 
		 double[] DRN =	 CopyRowArr(XR, 1, t.length); 
		 double[] DRH = CopyRowArr(XR, 2, t.length);
		 plot11.addLinePlot("RE", t,DRE); 
		 plot12.addLinePlot("RN", t,DRN); 
		 plot13.addLinePlot("RH", t,DRH);
		 
		 double[] DVE = CopyRowArr(XR, 3, t.length); 
		 double[] DVN = CopyRowArr(XR, 4, t.length); 
		 double[] DVH = CopyRowArr(XR, 5, t.length); 
		 plot21.addLinePlot("dVE", t,DVE);
		 plot22.addLinePlot("dVN", t,DVN); 
		 plot23.addLinePlot("dVH", t,DVH);
		 
		 double[] AlE = CopyRowArr(XR, 6, t.length); 
		 double[] AlN = CopyRowArr(XR, 7, t.length); 
		 double[] AlH = CopyRowArr(XR, 8, t.length); 
		 plot31.addLinePlot("AlE", t,AlE);
		 plot32.addLinePlot("AlN", t,AlN); 
		 plot33.addLinePlot("AlH", t,AlH);
		 
		 			 
		double[] GyE = CopyRowArr(XR, 9, t.length); 
		double[] GyN =CopyRowArr(XR, 10, t.length); 
		double[] GyH = CopyRowArr(XR, 11,t.length); 
		plot41.addLinePlot("GyE", t,GyE);
		plot42.addLinePlot("GyN", t,GyN); 
		plot43.addLinePlot("GyH", t,GyH);
			 
		double[] AccE = CopyRowArr(XR, 12, t.length); 
		double[] AccN =CopyRowArr(XR, 13, t.length); 
		double[] AccH = CopyRowArr(XR, 14,t.length); 
		plot51.addLinePlot("AccE", t,AccE);
		plot52.addLinePlot("AccN", t,AccN); 
		plot53.addLinePlot("AccH", t,AccH);	 
		 
		 	
		// double[][] Xdiff = minus(XP,XR);
		// System.out.println("RE = \n" + printDoubleArray(RE));
		// double[] RE = CopyRowArr(Xdiff, 1, FP.t.length);

	}
	public static void PlotKalmanXD() {
		
		 double[] DRE = CopyRowArr(XD, 0, t.length); 
		 double[] DRN =	 CopyRowArr(XD, 1, t.length); 
		 double[] DRH = CopyRowArr(XD, 2, t.length);
		 plot11.addLinePlot("RE", t,DRE); 
		 plot12.addLinePlot("RN", t,DRN); 
		 plot13.addLinePlot("RH", t,DRH);
		 
		 double[] DVE = CopyRowArr(XD, 3, t.length); 
		 double[] DVN = CopyRowArr(XD, 4, t.length); 
		 double[] DVH = CopyRowArr(XD, 5, t.length); 
		 plot21.addLinePlot("dVE", t,DVE);
		 plot22.addLinePlot("dVN", t,DVN); 
		 plot23.addLinePlot("dVH", t,DVH);
		 
		 double[] AlE = CopyRowArr(XD, 6, t.length); 
		 double[] AlN = CopyRowArr(XD, 7, t.length); 
		 double[] AlH = CopyRowArr(XD, 8, t.length); 
		 plot31.addLinePlot("AlE", t,AlE);
		 plot32.addLinePlot("AlN", t,AlN); 
		 plot33.addLinePlot("AlH", t,AlH);
		 
		 			 
		double[] GyE = CopyRowArr(XD, 9, t.length); 
		double[] GyN =CopyRowArr(XD, 10, t.length); 
		double[] GyH = CopyRowArr(XD, 11,t.length); 
		plot41.addLinePlot("GyE", t,GyE);
		plot42.addLinePlot("GyN", t,GyN); 
		plot43.addLinePlot("GyH", t,GyH);
			 
		double[] AccE = CopyRowArr(XD, 12, t.length); 
		double[] AccN =CopyRowArr(XD, 13, t.length); 
		double[] AccH = CopyRowArr(XD, 14,t.length); 
		plot51.addLinePlot("AccE", t,AccE);
		plot52.addLinePlot("AccN", t,AccN); 
		plot53.addLinePlot("AccH", t,AccH);	 
		 
		 	
		// double[][] Xdiff = minus(XP,XR);
		// System.out.println("RE = \n" + printDoubleArray(RE));
		// double[] RE = CopyRowArr(Xdiff, 1, FP.t.length);

	}
	public static void CalcKalman() {

		RunISNS Sys = new RunISNS();

		double[][] Z;
		double[][] K;
		double[][] B;// = Sys.ComputeB(Pitch[0], Yaw[0], Roll[0]);
		double[][] F;// = Sys.ComputeF(Phi[0], B,H[0], VE[0],VN[0],VH[0],
						// AE[0],AN[0],AH[0],stepTime,t[0]);
		double[][] Q;// =
						// Sys.ComputeQ(B,FP.Phi[0],FP.t[0],FP.stepTime,FP.VE[0],FP.VN[0]);
		double[][] Ho;// = Sys.ComputeH();
		double[][] R;// = Sys.CouputeR(FP.Phi[0]);
		double[][] Pm;
		double[][] Pp = Sys.InitPp();

		double[][] Xm;
		XP = new double[22][t.length];
		XR = new double[22][t.length];

		// double[][] Ksi = Sys.RandomKsi(34);
		double[][] Xp = Sys.InitXp();
		double[][] Xt = Sys.InitXp();
		int k = 1;

		XR = PasteCol(XR, 0, Xt);
		XP = PasteCol(XP, 0, Xp);
		Ho = Sys.ComputeH();

		for (k = 1; k < t.length; k++) {
			B = Sys.ComputeB(Pitch[k - 1], Yaw[k - 1], Roll[k - 1]);
			F = Sys.ComputeF(Phi[k - 1], B, H[k - 1], VE[k - 1], VN[k - 1],
					VH[k - 1], AE[k - 1], AN[k - 1], AH[k - 1], stepTime,
					t[k - 1]);

			Q = Sys.ComputeQ(B, Phi[k - 1], t[k - 1], stepTime, VE[k - 1],
					VN[k - 1]);
			R = Sys.CouputeR(Phi[k - 1]);
			Xt = plus(times(F, Xt), times(Q, Sys.RandomKsi(34)));
			// Xt = times(F,Xt);
			XR = PasteCol(XR, k, Xt);

			Xm = times(F, Xp);

			Pm = plus(times(times(F, Pp), transpose(F)), times(Q, transpose(Q)));

			Z = plus(times(Ho, Xt), times(R, Sys.RandomKsi(13)));

			K = times(times(Pm, transpose(Ho)),	inverse(plus(times(times(Ho, Pm), transpose(Ho)), times(R,
					transpose(R)))));


			Pp = plus(times(times(minus(identity(22), times(K, Ho)), Pm),
					transpose(minus(identity(22), times(K, Ho)))),
			times(times(times(K, R), transpose(R)), transpose(K)));
			Xp = plus(Xm, times(K, minus(Z, times(Ho, Xm))));
			XP = PasteCol(XP, k, Xp);

		}
		XD = minus(XP,XR);
	}

	public static void GenerateTrajectory() {
		
		ReadFlightPathForms();
		InitFlightPath();
		//ClearAllPlots();
		path3d.addLinePlot("3DLine", Rad2Deg(Phi), Rad2Deg(Lam), H);
		pathPitch.addLinePlot("Pitch", t, Rad2Deg(Pitch));
		pathYaw.addLinePlot("Yaw", t, Rad2Deg(Yaw));
		pathRoll.addLinePlot("Roll", t, Rad2Deg(Roll));

		CalcKalman();
		//PlotKalmanXP();
		PlotKalmanXD();
		
		
		
	}

	public static void ReadFlightPathForms() {
		try {
			simTime = Double.parseDouble(FPset.TextfieldTime.getText());
			stepTime = Double.parseDouble(FPset.TextfieldStepTme.getText());
			Phi0 = Double.parseDouble(FPset.TextfieldPhi0.getText());
			Lam0 = Double.parseDouble(FPset.TextfieldLam0.getText());
			H0 = Double.parseDouble(FPset.TextfieldH0.getText());
			TPhi = Double.parseDouble(FPset.TextfieldTPhi.getText());
			TLam = Double.parseDouble(FPset.TextfieldTLam.getText());
			TH = Double.parseDouble(FPset.TextfieldTH.getText());

			deltaPhi = Double.parseDouble(FPset.TextfieldDeltaPhi.getText());
			deltaLam = Double.parseDouble(FPset.TextfieldDeltaLam.getText());
			deltaH = Double.parseDouble(FPset.TextfieldDeltaH.getText());
			ddeltaPhi = Double.parseDouble(FPset.TextfieldDdeltaPhi.getText());
			ddeltaLam = Double.parseDouble(FPset.TextfieldDdeltaLam.getText());
			ddeltaH = Double.parseDouble(FPset.TextfieldDdeltaH.getText());
			kPhi = Double.parseDouble(FPset.TextfieldKPhi.getText());
			kLam = Double.parseDouble(FPset.TextfieldKLam.getText());
			WPhi = 2 * Math.PI / TPhi;
			WLam = 2 * Math.PI / TLam;
			WH = 2 * Math.PI / TH;

		} catch (NumberFormatException nfe) {
			System.out.println("Improper input");
			JOptionPane.showMessageDialog(null, "FIRE!");
		}

	}

	public static void InitFlightPath() {

		FlightPathGen FP = new FlightPathGen();

		FP.simTime = simTime;
		FP.stepTime = stepTime;
		FP.Phi0 = Phi0;
		FP.Lam0 = Lam0;
		FP.H0 = H0;
		FP.TPhi = TPhi;
		FP.TLam = TLam;
		FP.TH = TH;
		FP.kPhi = kPhi;
		FP.kLam = kLam;
		FP.deltaPhi = deltaPhi;
		FP.deltaLam = deltaLam;
		FP.deltaH = deltaH;
		FP.ddeltaPhi = ddeltaPhi;
		FP.ddeltaLam = ddeltaLam;
		FP.ddeltaH = ddeltaH;
		FP.WPhi = 2 * Math.PI / TPhi;
		FP.WLam = 2 * Math.PI / TLam;
		FP.WH = 2 * Math.PI / TH;
		FP.t = FlightPathGen.loadTimeArray(simTime, stepTime);

		FP.InitPathVars();
		FP.ComputePhiLamH();
		FP.ComputeR1R2();
		FP.ComputeVenhr();
		FP.ComputeAenh();
		FP.ComputePRY();

		Phi = FP.Phi;
		Lam = FP.Lam;
		H = FP.H;
		Pitch = FP.Pitch;
		Yaw = FP.Yaw;
		Roll = FP.Roll;
		VE = FP.VE;
		VN = FP.VN;
		VH = FP.VH;
		AE = FP.AE;
		AN = FP.AN;
		AH = FP.AH;
		t = FP.t;
	}

	static double[] Rad2Deg(double[] Rad) {
		double[] Deg = new double[Rad.length];
		for (int i = 0; i < Rad.length; i++)
			Deg[i] = 180 * Rad[i] / Math.PI;
		return Deg;
	}

	public static double[][] PasteCol(double[][] M, int Pos, double X[][]) {

		for (int i = 0; i < 22; i++) {
			M[i][Pos] = X[i][0];
			// System.out.println("i= " + i);
		}
		return M;
	}

	public static double[] CopyRowArr(double[][] M, int Pos, int len) {
		double[] array = new double[len];
		for (int i = 0; i < len; i++) {
			array[i] = M[Pos][i];

			// System.out.println("i= " + i);
		}
		return array;
	}

	static double Deg2Rad(double Deg) {
		return Math.PI * Deg / 180;
	}

	private static void createAndShowGUI() {
		// Create and set up the window.
		frame = new JFrame("jKalman");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Set up the content pane.
		addComponentsToPane(frame.getContentPane());

		// Display the window.
		frame.pack();
		frame.setSize(1000, 700);
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		// Schedule a job for the event-dispatching thread:
		// creating and showing this application's GUI.
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createAndShowGUI();
			}
		});
	}

}
