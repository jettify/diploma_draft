package jKalman;
//package flightpath;


import static org.math.io.parser.ArrayString.printDoubleArray;
import java.util.Random;

public class RunISNS {
	double[][] Fisns;// = new double[22][22];
	double[][] Risns;// = new double[8][13];
	double[][] Qisns;// = new double[22][28];
	double[][] Pp = new double[22][22];
	double[][] Pm = new double[22][22];
	double[][] Xp = new double[22][1];
	double[][] Xm = new double[22][1];
	double[][] Z = new double[8][1];
	double[][] H;// = new double[8][22];
	double[][] B;//q = new double[3][3];
	double lam_s;
	double lam_st;
	double lam_v;
	int miu = 0;
	double[] SigmaI = {0.001,0.001,0.001,
			1E-4,1E-4,1E-4,
			1E-8,1E-8,1E-8,
			1E-10,1E-10,1E-10,
			1E-7,1E-7,1E-7};

	double SigmaA;
	double SigmaW;

	
	// elements of R - matrix of SNS
	// errors of SNS
	double SigmaRS;
	double SigmadRS;
	double SigmaHS;
	double SigmaVS;
	double SigmadVS;
	double SigmaBa;
	// correlated errors of SNS
	double SigmaRC;
	double SigmadRC;
	double SigmaVC;
	double SigmadVC;
	double SigmaHC;
	double SigmadHC;
	
	RunISNS(){
		super();
		SigmaA = 1E-3;
		SigmaW = 1E-6;
		
		lam_s = 4E-6; // m^-1
		lam_st = 5E-4; // c^-1
		lam_v = 0.01; // c^-1 (0.0017 - 0.05)
		// elements of R - matrix of SNS
		// errors of SNS
		SigmaRS = 3;                // m (1-3)
		SigmadRS = 4;               // m (1-4)
		SigmaHS = 4;                // m (1.5-4)
		SigmaVS = 0.04;             // m/s (0.001-0.05)
		SigmadVS = 0.2;             // v/s (0.02-0.2)
		SigmaBa = 10;               // m
		// correlated errors of SNS
		SigmaRC = 7;                // m (5-7)
		SigmadRC = 5;               // m (2-5)
		SigmaVC = 0.3;              // m/s (0.02-0.3)
		SigmadVC = 0.02;            // m/s (0.01-0.02)
		SigmaHC = 10;               // m (7-10)
		SigmadHC = 7;               // m (3-7)
		
		
	
		
		
	}
	
	double[][] ComputeF(double phi,double[][] b,double h,double V_E,double V_N,double V_h, double a_E, double a_N, double a_h, double dt, double t){
		double[][] F = Zeros(22);
		
		double R = FlightPathGen.EARTH_RADIUS + h;
		double Rz = FlightPathGen.EARTH_RADIUS;
		double dlam1 = V_E/(R*(Math.cos(phi)));
		double dphi1 = V_N/R;
		double u = FlightPathGen.EARTH_SPEED;
		double w_1E = -dphi1; 
		double w_1N = (u+dlam1)*Math.cos(phi);
		double w_1h = (u+dlam1)*Math.sin(phi);
		double e2 = FlightPathGen.E2;
		double ge = FlightPathGen.GE;
		double a = FlightPathGen.EARTH_RADIUS;
		
		for(int i=0;i<22;i++)
			for(int j=0;j<22;j++)
				F[i][j] = 0;
		
		
		F[0][1] = (dlam1/Rz)*Math.tan(phi);
		F[0][2] = -(dlam1*Rz)/R;
		F[0][3] = Rz/(R*Math.cos(phi));
		
		F[1][2] = -dphi1*(Rz/R);
		F[1][4] =Rz/R;

		F[2][5]=1;

		F[3][1] = ((2*u+dlam1)/Rz)*(V_h*Math.sin(phi)+V_N*Math.cos(phi))- (dlam1/Rz)*Math.tan(phi)*(V_h*Math.cos(phi)-V_N*Math.sin(phi)); 
		F[3][2] = (V_E/(R*R))*(V_h-V_N*Math.tan(phi));
		F[3][3] = -(V_h*Math.cos(phi)-V_N*Math.sin(phi))/(R*Math.cos(phi)); 
		F[3][4] = (2*u+dlam1)*Math.sin(phi);
		F[3][5] = -(2*u+dlam1)*Math.cos(phi);
		F[3][7] = -a_h; 
		F[3][8] = a_N;
		F[3][12] = b[0][0];
		F[3][13] = b[0][1]; 
		F[3][14] = b[0][2];

		F[4][1] = -(2*u + dlam1)*V_E*Math.cos(phi)*(1/Rz) - ((V_E*V_E)*Math.pow(Math.tan(phi),2))/(Rz*R); 
		F[4][2] = ((Math.pow(V_E,2))*Math.tan(phi)+V_N*V_h)*Math.pow(R,-2); 
		F[4][3] = -2*(u+dlam1)*Math.sin(phi)-V_E*Math.tan(phi)*(1/R); 
		F[4][4] = -V_h/R; 
		F[4][5] = -dphi1; 
		F[4][6] = a_h;
		F[4][8] = -a_E;
		F[4][12] = b[1][0];
		F[4][13] = b[1][1];
		F[4][14] = b[1][2];

		F[5][1] = - V_E*(2*u+dlam1)*Math.sin(phi)*(1/Rz)+ ((Math.pow(V_E,2))*Math.tan(phi))/(Rz*R)+ 1.5*(ge/Rz)*e2*Math.sin(phi)*Math.cos(phi);
		F[5][2] = -(ge*2)/a - (Math.pow(V_E,2)+Math.pow(V_N,2))/(R*R);
		F[5][3] = 2*(u+dlam1)*Math.cos(phi)+V_E/R;
		F[5][4] = dphi1+V_N/R;
		F[5][6] = -a_N;
		F[5][7] = a_E;
		F[5][12] = b[2][0];
		F[5][13] = b[2][1];
		F[5][14] = b[2][2];

		F[6][4] = -(1/R);
		F[6][7] = w_1h;
		F[6][8] = -w_1N;
		F[6][9] = -b[0][0];
		F[6][10] = -b[0][1];
		F[6][11] = -b[0][2];

		F[7][1] = -u*Math.sin(phi)*(1/Rz);
		F[7][3] = (1/R);
		F[7][6] = -w_1h;
		F[7][8] = w_1E;
		F[7][9] = -b[1][0];
		F[7][10] = -b[1][1];
		F[7][11] = -b[1][2];

		F[8][1] = ((u*Math.cos(phi)+dlam1/Math.cos(phi))*(1/Rz));
		F[8][3] = (Math.tan(phi)/R);
		F[8][6] = w_1N;
		F[8][7] = -w_1E;
		F[8][9] = -b[2][0];
		F[8][10] = -b[2][1];
		F[8][11] = -b[2][2];
		
		// SNS part of matrix
		double V_r = Math.sqrt(Math.pow(V_E, 2) + Math.pow(V_N, 2));
		double W_R = Math.exp(-(lam_s*V_r+lam_st)*dt); 
		double W_V = Math.exp(-lam_v*t); 
		
		F[16][16] = W_R;
		F[17][17] = W_R;
		F[18][18] = W_R;
		F[19][19] = W_V;
		F[20][20] = W_V;
		F[21][21] = W_V;
		
		// convert system from continuous to discrete time
		for(int i=0;i<16;i++)
			for(int j=0;j<16;j++){
				F[i][j] = F[i][j]*dt;
				if (i==j)
					F[i][j] = F[i][j] +1;
			}
				
		
		//System.out.println("F = \n" + printDoubleArray(F));
		return F;
		
	}
	double[][] ComputeB(double pitch, double yaw, double roll){
		double[][] b = new double[3][3];
		b[0][0] = Math.sin(yaw)*Math.cos(pitch);
		b[1][0] = Math.cos(yaw)*Math.cos(pitch);
		b[2][0] = Math.sin(pitch);

		b[0][1] = Math.cos(yaw)*Math.sin(roll)-Math.sin(yaw)*Math.cos(roll)*Math.sin(pitch);
		b[1][1] = -Math.sin(yaw)*Math.sin(roll)-Math.cos(yaw)*Math.cos(roll)*Math.sin(pitch);
		b[2][1] = Math.cos(roll)*Math.cos(pitch);

		b[0][2] = Math.cos(yaw)*Math.cos(roll)+Math.sin(yaw)*Math.sin(roll)*Math.sin(pitch);
		b[1][2] = -Math.sin(yaw)*Math.cos(roll)+Math.cos(yaw)*Math.sin(roll)*Math.sin(pitch);
		b[2][2] = -Math.sin(roll)*Math.cos(pitch);
		// System.out.println("b = \n" + printDoubleArray(b));
		return b;
		
	}
	double[][] ComputeQ(double[][] b,double phi,double t, double dt, double V_E,double V_N){
		
		double[][] Q = Zeros(22,34);
		// INS 15x21
		for (int i=0;i<SigmaI.length;i++)
		{	
				Q[i][i] = SigmaI[i];
		}
		for (int i=0; i<3; i++){
			for (int j=0; j<3; j++){
				Q[i+3][j+18] = b[i][j]*SigmaA;
				Q[i+6][j+15] = -b[i][j]*SigmaW;
			}
		}
		// Baro altimeter
		Q[15][21] = SigmaBa*Math.sqrt(dt);
		// SNS 6x12
		double V_r = Math.sqrt(Math.pow(V_E, 2) + Math.pow(V_N, 2));
		double q_R = Math.sqrt(1-Math.exp((-2*(lam_s*V_r+lam_st))*dt)); 
		double q_V = Math.sqrt(1-Math.exp(-2*lam_v*dt)); 
		
		Q[16][22] =q_R*SigmaRC/Math.cos(phi) ;
		Q[17][23] =q_R*SigmaRC ;
		Q[18][24] =q_R*SigmaHC ;
		Q[19][25] =q_V*SigmaVC ;		
		Q[20][26] =q_V*SigmaVC ;
		Q[21][27] =q_V*SigmaVC ;		
		
		
		// System.out.println("Q = \n" + printDoubleArray(Q));
		return Q;
	}
	double[][] ComputeH(){
		H = Zeros(8,22);
		H[0][2] = 1; H[0][15]=-1;
		H[1][0] = 1; H[1][16]=-1;
		H[2][1] = 1; H[2][17]=-1;
		H[3][2] = 1; H[3][18]=-1;		
		H[4][3] = 1; H[4][19]=-1;
		H[5][4] = 1; H[5][20]=-1;
		H[6][5] = 1; H[6][21]=-1;
		H[7][15] = 1; H[7][18]=-1;
		//System.out.println("H = \n" + printDoubleArray(H));
		return H;
	}
	double[][] CouputeR(double phi){
		double[][] R = Zeros(8,13);
		R[0][0] = SigmaBa;
		R[1][1] = SigmaRS/Math.cos(phi);
		R[2][2] = SigmaRS;
		R[3][3] = SigmaHS;
		R[4][4] = SigmaVS;
		R[5][5] = SigmaVS;
		R[6][6] = SigmaVS;
		R[7][0] = SigmaBa;R[7][3] = SigmaHS;
		// System.out.println("R = \n" + printDoubleArray(R));
		return R;
	}
	double[][] InitPp(){
		// cov state of SDINS
		//Pp_ins = [100 100 50 5 5 5 10^-3 10^-3 3*10^-3 ...
		//   10^-5 10^-5 10^-5 10^-3 10^-3 10^-3];
		// cov state of baro altimeter
		//Pp_ba = 10;
		// cov state of SNS
		//Pp_sns =[5 5 5 0.3 0.3 0.3];10^
		double[][] Pp;
		double[] Pdiag = {Math.pow(100,2), Math.pow(100,2), Math.pow(50,2), Math.pow(5,2), Math.pow(5,2), Math.pow(5,2),
				Math.pow(1E-3,2), Math.pow(1E-3,2), Math.pow(3*1E-3,2), Math.pow(1E-5,2), Math.pow(1E-5,2), Math.pow(1E-5,2),
				Math.pow(1E-3,2), Math.pow(1E-3,2), Math.pow(1E-3,2),Math.pow(10,2),Math.pow(5,2), Math.pow(5,2), Math.pow(5,2), Math.pow(0.3,2), Math.pow(0.3,2), Math.pow(0.3,2)};
		Pp = Diag(Pdiag);
		//System.out.println("Pp = \n" + printDoubleArray(Pp));
		return Pp;
		
	}
	double[][] InitXp(){

		
		double[][] Xp = {{120}, {-100}, {70}, {5}, {-5}, {1}, 
				{1E-3}, {1E-3}, {3*1E-3},  {1E-4}, {-5*1E-4}, {7*1E-4}, 
				{8*1E-2}, {-1E-2}, {-1E-2}, {15}, {2}, {5}, {7}, {0.01}, {0.02}, {0.01}};
		
		
		//System.out.println("InitXp = \n" + printDoubleArray(Xp));
		return Xp;
	}
	double[][] RandomKsi(int size){
		double [][] Ksi = new double [size][1];
		Random r = new Random();
		for (int i=0; i< size;i++)
			Ksi [i][0] = r.nextGaussian();
		return Ksi;
	}
	
	public static double[][] Zeros(int n, int m){
		double[][] z = new double[n][m];
		for(int i=0;i<n;i++)
			for(int j=0;j<m;j++)
				z[i][j] = 0;
		return z;
		}
	public static double[][] Zeros(int n){
		double[][] z = new double[n][n];
		for(int i=0;i<n;i++)
			for(int j=0;j<n;j++)
				z[i][j] = 0;
		return z;
		}
	public static double[][] Diag (double[] diag){
		double[][] matrix = Zeros(diag.length);
		for(int i=0;i<diag.length;i++)
			matrix[i][i] = diag[i];
		return matrix;
		}
	
	

}