/**
 * 
 */
package jKalman;

/**

 * @author Mykola Novik
 * java -Dsun.java2d.pmoffscreen=false
 */
import javax.swing.*;
import java.awt.*;
//import java.awt.event.*;

//import java.util.*;

//import java.awt.Color;
//import java.awt.LayoutManager;
//import java.io.*;
//import math lib
//import java.lang.Math.*;

// import math array lib
//import static org.math.array.DoubleArray.*;
//import static org.math.array.LinearAlgebra.*;
//import static org.math.array.StatisticSample.*;

// import input/output library
//import static org.math.io.files.ASCIIFile.*;
//import static org.math.io.parser.ArrayString.*;
// import graph plot library
import org.math.plot.*;

public class FlightPathGen {
	

	// Radius of Earth, m
	final static double EARTH_RADIUS = 6378137 ;
	// Angular velocity of Earth, rad/sec
	final static double EARTH_SPEED = 7.292115E-5; 
	// Const for WGS84 e^2
	final static double E2 = 6.6943799901413E-3;
	final static double MIU = 398600.44E9; // m^3/c^2
	final static double GE = MIU/(Math.pow(EARTH_RADIUS,2));
	
	double simTime ; 
	// Step time, s
	double stepTime ; 
	int stepCount  ;
	double [] t;
	// Parameters of motion of aircraft
	// Start point on surface of Earth, lat, long, height
	private double Phi0 ;
	private double Lam0 ;
	private double H0 ;

	// Parameter of oscilation of flight path
	private double TPhi ;
	private double TLam ;
	private double TH ;
	
	private double kPhi ;
	private double kLam ;
	private double deltaPhi ; 
	private double deltaLam ;
	private double deltaH ;
	
	private double ddeltaPhi ;
	private double ddeltaLam ;
	private double ddeltaH  ;
	
	private double WPhi ;
	private double WLam ;
	private double WH ;
	
	double[] Phi;
	double[] Lam;
	double[] H;
	private double[] dPhi;
	private double[] dLam;
	private double[] dH;	
	private double[] ddPhi;
	private double[] ddLam;
	private double[] ddH;	
	private double[] R1;	
	private double[] R2;	
	private double[] dR1;	
	private double[] dR2;	
	double[] VE;
	double[] VN;
	double[] VH;
	double[] VR;
	private double[] dVE;
	private double[] dVN;
	private double[] dVH;
	double[] AE;
	double[] AN;
	double[] AH;
	private double[] q;
	private double[] g;
	double[] Pitch;
	double[] Yaw;
	double[] Roll;
	
	FlightPathGen(){
		//////////////////////////////////////////////////
		//////////////////////////////////////////////////
		//////////////////////////////////////////////////
		simTime = 1000 ; 
		// Step time, s
		stepTime = 1; 
		stepCount = (int) (simTime/stepTime);
		
		// Parameters of motion of aircraft
		// Start point on surface of Earth, lat, long, height
		Phi0 = 55*(Math.PI/180) ;
		Lam0 = 30*(Math.PI/180) ;
		H0 = 5000;

		// Parameter of oscilation of flight path
		TPhi = 600;
		TLam = 600;
		TH = 600;
		
		kPhi = 0;
		kLam = 0.00004;
		deltaPhi = 0.004; 
		deltaLam = 0;
		deltaH = H0;
		
		ddeltaPhi = 0;
		ddeltaLam = 0;
		ddeltaH = 0;
		
		WPhi = 2*Math.PI/TPhi;
		WLam = 2*Math.PI/TLam;
		WH = 2*Math.PI/TH;
		InitPathVars();
		t = loadTimeArray();
	}
	FlightPathGen(double[] time, double[] pathPos0, double[] pathTpos,double[] kPos, double[] deltaPos, double[] ddeltaPos ){
		simTime = time[0]; 
		// Step time, s
		stepTime = time[1]; 
		stepCount = (int) (simTime/stepTime);
		
		// Parameters of motion of aircraft
		// Start point on surface of Earth, lat, long, height
		Phi0 = pathPos0[0]*(Math.PI/180) ;
		Lam0 = pathPos0[1]*(Math.PI/180) ;
		H0 = pathPos0[2];

		// Parameter of oscilation of flight path
		TPhi = pathTpos[0];
		TLam = pathTpos[1];
		TH = pathTpos[2];
		
		kPhi = kPos[0];
		kLam = kPos[1];
		deltaPhi = deltaPos[0]; 
		deltaLam = deltaPos[1];
		deltaH = deltaPos[2];
		
		ddeltaPhi = ddeltaPos[0];
		ddeltaLam = ddeltaPos[1];
		ddeltaH = ddeltaPos[2];
		
		WPhi = 2*Math.PI/TPhi;
		WLam = 2*Math.PI/TLam;
		WH = 2*Math.PI/TH;
		InitPathVars();
		t = loadTimeArray();
	}
	void InitPathVars(){
		Phi = new double[stepCount];
		Lam = new double[stepCount];
		H = new double[stepCount];
		dPhi = new double[stepCount];
		dLam = new double[stepCount];
		dH = new double[stepCount];	
		ddPhi = new double[stepCount];
		ddLam = new double[stepCount];
		ddH = new double[stepCount];	
		R1 = new double[stepCount];	
		R2 = new double[stepCount];	
		dR1 = new double[stepCount];	
		dR2 = new double[stepCount];	
		VE = new double[stepCount];
		VN = new double[stepCount];
		VH = new double[stepCount];
		VR = new double[stepCount];
		dVE = new double[stepCount];
		dVN = new double[stepCount];
		dVH = new double[stepCount];
		AE = new double[stepCount];
		AN = new double[stepCount];
		AH = new double[stepCount];
		q = new double[stepCount];
		g = new double[stepCount];
		Pitch = new double[stepCount];
		Yaw = new double[stepCount];
		Roll = new double[stepCount];
		
	}
	double[] loadTimeArray(){
		int stepCount = (int) (simTime/stepTime);
		double[] Time = new double[stepCount];
		for (int i=0; i<stepCount; i++){
			Time[i] = i*stepTime; 
		}
		return Time;
	}
	
	void ComputePhiLamH (){
		/* phi = phi0 + Kphi*t +delta_phi*sin(w_phi*t + ddelta_phi);
		 * lam = lam0 + Klam*t +delta_lam*sin(w_lam*t + ddelta_lam);
		 * h = h0 - delta_h0*cos(w_h*t+ddelta_h);
		 * dphi =  Kphi + delta_phi*w_phi*cos(w_phi*t + ddelta_phi);
		 * dlam =  Klam + delta_lam*w_lam*cos(w_lam*t + ddelta_lam);
		 * dh = delta_h0*w_h*sin(w_h*t+ddelta_h);
		 * ddphi =  - delta_phi*(w_phi^2)*sin(w_phi*t + ddelta_phi);
		 * ddlam =  - delta_lam*(w_lam^2)*sin(w_lam*t + ddelta_lam);
		 * ddh = delta_h0*(w_h^2)*cos(w_h*t+ddelta_h);
		 * */
		
		for (int i=0; i<stepCount; i++){
			Phi[i] =  Phi0 + kPhi*t[i] +deltaPhi*Math.sin(WPhi*t[i] + ddeltaPhi);	
			Lam[i] =  Lam0 + kLam*t[i] +deltaLam*Math.sin(WLam*t[i] + ddeltaLam);	
			H[i] = H0 - deltaH*Math.cos(WH*t[i] + ddeltaH);
			
			dPhi[i] =  kPhi + deltaPhi*WPhi*Math.cos(WPhi*t[i] + ddeltaPhi);	
			dLam[i] =  kLam + deltaLam*WLam*Math.cos(WLam*t[i] + ddeltaLam);		
			dH[i] =  deltaH*WH*Math.sin(WH*t[i] + ddeltaH);
			
			ddPhi[i] = - deltaPhi*(Math.pow(WPhi,2))*Math.sin(WPhi*t[i] + ddeltaPhi);	
			ddLam[i] =  - deltaLam*(Math.pow(WLam,2))*Math.sin(WLam*t[i] + ddeltaLam);			
			ddH[i] =  deltaH*(Math.pow(WH, 2)*Math.cos(WH*t[i] + ddeltaH));			
			
		}
	}
	void ComputeR1R2(){
		/* a = 6378137; % m
		 * e2 =  6.66943799901413*10^-3;
		 * R1 = a./(1-(e2)*sin(phi).^2).^0.5;
		 * R2 = R1.*((1-e2)./(1-e2*(sin(phi).^2)));
		 * dR1 = (a*e2*sin(phi).*cos(phi).*dphi)./(1-e2*sin(phi).^2).^1.5;
		 * dR2 = dR1.*((1-e2)./(1-e2*sin(phi).^2)) + ...
		 * R1.*((1-e2)*2*e2.*sin(phi).*cos(phi).*dphi)./(1-e2.*sin(phi).^2).^2;
 		 * */
		for (int i=0; i<stepCount; i++){
			R1[i] = EARTH_RADIUS/Math.sqrt(1-E2*Math.pow(Math.sin(Phi[i]),2));
			R2[i] = (R1[i]*(1-E2))/(1-E2*Math.pow(Math.sin(Phi[i]),2));
			dR1[i] = (EARTH_RADIUS*E2*Math.sin(Phi[i])*Math.cos(Phi[i])*dPhi[i])/Math.pow(1-E2*Math.pow(Math.sin(Phi[i]),2),1.5);
			dR2[i] = dR1[i]*((1-E2)/(1-E2*Math.pow(Math.sin(Phi[i]),2))) + R1[i]*((1-E2)*2*E2*Math.sin(Phi[i])*Math.cos(Phi[i])*dPhi[i])/Math.pow(1-E2*Math.pow(Math.sin(Phi[i]),2),2);
			
		}
	}
	void ComputeVenhr(){
		/*
		 * V_N = dphi.*(R2 +h);
		 * V_E = dlam.*(R1 +h).*cos(phi);
		 * V_h = dh;

		 * dV_N = ddphi.*(R2 + h) + dphi.*(dR2 + dh);
		 * dV_E = ddlam.*(R1 + h).*cos(phi) + dlam.*(dR1 + dh).*cos(phi)-...
		 * dlam.*(R1 + h).*sin(phi).*dphi;
		 * dV_h = ddh;
		q = dlam + 2*wz;
		g = get_g(phi,h);
		*/
		
		for (int i=0; i<stepCount; i++){
			VN[i] = dPhi[i]*(R2[i] +H[i]);
			VE[i] = dLam[i]*(R1[i] +H[i])*Math.cos(Phi[i]);
			VH[i]= dH[i];
			dVN[i] = ddPhi[i]*(R2[i] + H[i]) + dPhi[i]*(dR2[i] + dH[i]);
			dVE[i] = ddLam[i]*(R1[i] + H[i])*Math.cos(Phi[i]) + dLam[i]*(dR1[i] + dH[i])*Math.cos(Phi[i]) - dLam[i]*(R1[i] + H[i])*Math.sin(Phi[i])*dPhi[i];
			dVH[i] = ddH[i];
			VR[i] = Math.sqrt(Math.pow(VE[i], 2) + Math.pow(VN[i], 2));
		}
	}
	void ComputeAenh(){
		/*
		 * q = dlam + 2*wz;
		 * g = get_g(phi,h);
		 * a_N = dV_N + q.*sin(phi).*V_E + dphi.*V_h;
		 * a_E = dV_E - q.*sin(phi).*V_N+q.*cos(phi).*V_h;
		 * a_h = dV_h - q.*cos(phi).*V_E - dphi.*V_N + g;
		 */

		for (int i=0; i<stepCount; i++){
			
			 q[i] = dLam[i] + 2*EARTH_SPEED;
			 g[i] = (MIU/Math.pow(EARTH_RADIUS,2))*(1 - 2*(H[i]/EARTH_RADIUS)+0.75*E2*Math.pow(Math.sin(Phi[i]),2));
			 
			 AE[i] = dVE[i] - q[i]*Math.sin(Phi[i])*VN[i]+q[i]*Math.cos(Phi[i])*VH[i]; 
			 AN[i] = dVN[i] + q[i]*Math.sin(Phi[i])*VE[i] + dPhi[i]*VH[i];
			 AH[i] = dVH[i] - q[i]*Math.cos(Phi[i])*VE[i] - dPhi[i]*VN[i] + g[i];
		}
	}
	void ComputePRY(){
		/*
		* pitch = atan2(V_h,V_r);
		* yaw = atan2(V_E,V_N);
		* Kg = 0.1; % rad/(m/s^2)
		* roll = Kg*(V_N.*dV_E - V_E.*dV_N)./(V_r.*cos(pitch));
		* pitch = atan2(V_h,V_r);*/
		for (int i=0; i<stepCount; i++){
			Pitch[i] = Math.atan2(VH[i],VR[i]);
			Yaw[i] = Math.atan2(VE[i],VN[i]);
			double Kg = 0.1; // rad/(m/s^2)
			Roll[i] = Kg*(VN[i]*dVE[i] - VE[i]*dVN[i])/(VR[i]*Math.cos(Pitch[i]));
			}
	}
	
	
	double [] GetPhi(){
		return Phi;
	}
	double [] GetLam(){
		return Lam;
	}
	double [] GetH(){
		return H;
	}
	double [] GetVE(){
		return VE;
	}
	double [] GetVN(){
		return VN;
	}
	double [] GetVH(){
		return VH;
	}
	double [] GetAE(){
		return AE;
	}
	double [] GetAN(){
		return AN;
	}
	double [] GetAH(){
		return AH;
	}
	
}
