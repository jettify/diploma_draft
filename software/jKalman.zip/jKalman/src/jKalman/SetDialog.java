package jKalman;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class SetDialog extends JDialog {
  public SetDialog(JFrame parent) {
    super(parent, "ISNS SETTINGS", true);

    Box b = Box.createVerticalBox();
    b.add(Box.createGlue());
    b.add(new JLabel("Settings fro INS"));

    b.add(Box.createGlue());
    
    getContentPane().add(b, "Center");

    JPanel p2 = new JPanel();
    setLayout(new GridLayout(5, 4));
    
    JButton ok = new JButton("Ok");
    
    getContentPane().add(p2, "South");

    ok.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        setVisible(false);
      }
    });

    setSize(600, 200);
    
    JTextField TfSigmaA = new JTextField(String.valueOf("1E-3"));
    JTextField TfSigmaW = new JTextField(String.valueOf("1E-6"));
    JTextField TfSigmaI1 = new JTextField(String.valueOf("0.001"));
    JTextField TfSigmaI2 = new JTextField(String.valueOf("1E-4"));
    JTextField TfSigmaI3 = new JTextField(String.valueOf("1E-8"));
    JTextField TfSigmaI4 = new JTextField(String.valueOf("1E-10"));
    JTextField TfSigmaI5 = new JTextField(String.valueOf("1E-7"));
    JTextField TfSigmaRS = new JTextField(String.valueOf("3"));
    JTextField TfSigmaHS = new JTextField(String.valueOf("4"));
    JTextField TfSigmaVS = new JTextField(String.valueOf("0.04"));
    JTextField TfBa = new JTextField(String.valueOf("10"));
    JTextField TfSigmaRC = new JTextField(String.valueOf("7"));
    JTextField TfSigmaVC = new JTextField(String.valueOf("0.3"));
    JTextField TfSigmaHC = new JTextField(String.valueOf("10"));
    
    JLabel LbSigmaA = new JLabel("SigmaA", SwingConstants.LEFT);
    JLabel LbSigmaW = new JLabel("SigmaW", SwingConstants.LEFT);
    JLabel LbSigmaI1 = new JLabel("SigmaI 1-3", SwingConstants.LEFT);
    JLabel LbSigmaI2 = new JLabel("SigmaI 4-6", SwingConstants.LEFT);
    JLabel LbSigmaI3 = new JLabel("SigmaI 7-9", SwingConstants.LEFT);
    JLabel LbSigmaI4 = new JLabel("SigmaI 9-12", SwingConstants.LEFT);
    JLabel LbSigmaI5 = new JLabel("SigmaI 13-15", SwingConstants.LEFT);
    JLabel LbSigmaRS = new JLabel("SigmaRS", SwingConstants.LEFT);
    JLabel LbSigmaHS = new JLabel("SigmaHS", SwingConstants.LEFT);
    JLabel LbSigmaVS = new JLabel("SigmaVS", SwingConstants.LEFT);
    JLabel LbBa = new JLabel("SigmaBa", SwingConstants.LEFT);
    JLabel LbSigmaRC = new JLabel("SigmaRC", SwingConstants.LEFT);
    JLabel LbSigmaVC = new JLabel("SigmaVC", SwingConstants.LEFT);
    JLabel LbSigmaHC = new JLabel("SigmadHC", SwingConstants.LEFT);
    

    p2.add(LbSigmaA);	p2.add(TfSigmaA);
    p2.add(LbSigmaW);	p2.add(TfSigmaW);
    p2.add(LbSigmaI1);	p2.add(TfSigmaI1);
    p2.add(LbSigmaI2);	p2.add(TfSigmaI2);
    p2.add(LbSigmaI3);	p2.add(TfSigmaI3);
    p2.add(LbSigmaI4);	p2.add(TfSigmaI4);
    p2.add(LbSigmaI5);	p2.add(TfSigmaI5);
    p2.add(LbSigmaRS);	p2.add(TfSigmaRS);
    p2.add(LbSigmaHS);	p2.add(TfSigmaHS);
    p2.add(LbSigmaVS);	p2.add(TfSigmaVS);
    p2.add(LbBa);	p2.add(TfBa);
    p2.add(LbSigmaRC);	p2.add(TfSigmaRC);
    p2.add(LbSigmaVC);	p2.add(TfSigmaVC);
    p2.add(LbSigmaHC);	p2.add(TfSigmaHC);
    //p2.add(TextfieldKPhi);	add(label_KPhi);
   // p2.add(TextfieldKLam);	add(label_KLam);
    
    p2.add(ok);

    
    
  }
  
}