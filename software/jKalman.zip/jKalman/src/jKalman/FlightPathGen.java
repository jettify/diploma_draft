/**
 * 
 */
package jKalman;

/**

 * @author Mykola Novik
 * java -Dsun.java2d.pmoffscreen=false
 */
import javax.swing.*;
import java.awt.*;
//import java.awt.event.*;

//import java.util.*;

//import java.awt.Color;
//import java.awt.LayoutManager;
//import java.io.*;
//import math lib
//import java.lang.Math.*;

// import math array lib
//import static org.math.array.DoubleArray.*;
//import static org.math.array.LinearAlgebra.*;
//import static org.math.array.StatisticSample.*;

// import input/output library
//import static org.math.io.files.ASCIIFile.*;
//import static org.math.io.parser.ArrayString.*;
// import graph plot library
import org.math.plot.*;

public class FlightPathGen {
	

	// Radius of Earth, m
	final static double EARTH_RADIUS = 6378137 ;
	// Angular velocity of Earth, rad/sec
	final static double EARTH_SPEED = 7.292115E-5; 
	// Const for WGS84 e^2
	final static double E2 = 6.6943799901413E-3;
	final static double MIU = 398600.44E9; // m^3/c^2
	final static double GE = MIU/(Math.pow(EARTH_RADIUS,2));
	
	double simTime ; 
	// Step time, s
	double stepTime ; 
	int stepCount  ;
	double [] t;
	// Parameters of motion of aircraft
	// Start point on surface of Earth, lat, long, height
	double Phi0 ;
	double Lam0 ;
	double H0 ;

	// Parameter of oscilation of flight path
	double TPhi ;
	double TLam ;
	double TH ;
	
	double kPhi ;
	double kLam ;
	double deltaPhi ; 
	double deltaLam ;
	double deltaH ;
	
	double ddeltaPhi ;
	double ddeltaLam ;
	double ddeltaH  ;
	
	double WPhi ;
	double WLam ;
	double WH ;
	
	double[] Phi;
	double[] Lam;
	double[] H;
	double[] dPhi;
	double[] dLam;
	double[] dH;	
	double[] ddPhi;
	double[] ddLam;
	double[] ddH;	
	double[] R1;	
	double[] R2;	
	double[] dR1;	
	double[] dR2;	
	double[] VE;
	double[] VN;
	double[] VH;
	double[] VR;
	double[] dVE;
	double[] dVN;
	double[] dVH;
	double[] AE;
	double[] AN;
	double[] AH;
	double[] q;
	double[] g;
	double[] Pitch;
	double[] Yaw;
	double[] Roll;
	
	FlightPathGen(){
		//////////////////////////////////////////////////
		//////////////////////////////////////////////////
		//////////////////////////////////////////////////
		simTime = 1000 ; 
		// Step time, s
		stepTime = 1; 
		stepCount = (int) (simTime/stepTime);
		
		// Parameters of motion of aircraft
		// Start point on surface of Earth, lat, long, height
		Phi0 = 55*(Math.PI/180) ;
		Lam0 = 30*(Math.PI/180) ;
		H0 = 5000;

		// Parameter of oscilation of flight path
		TPhi = 600;
		TLam = 600;
		TH = 600;
		
		kPhi = 0;
		kLam = 0.00004;
		deltaPhi = 0.004; 
		deltaLam = 0;
		deltaH = H0;
		
		ddeltaPhi = 0;
		ddeltaLam = 0;
		ddeltaH = 0;
		
		WPhi = 2*Math.PI/TPhi;
		WLam = 2*Math.PI/TLam;
		WH = 2*Math.PI/TH;
		t = loadTimeArray(simTime,stepTime);
		InitPathVars();
		
	}
	FlightPathGen(double simtime, double steptime,
			double phi0,double lam0,double h0,
			double tphi, double tlam,double th,
			double kphi, double klam,
			double deltaphi, double deltalam, double deltah,
			double ddeltaphi, double ddeltalam, double ddeltah){
		//////////////////////////////////////////////////
		//////////////////////////////////////////////////
		//////////////////////////////////////////////////
		simTime = simtime ; 
		// Step time, s
		stepTime = steptime; 
		stepCount = (int) (simTime/stepTime);
		
		// Parameters of motion of aircraft
		// Start point on surface of Earth, lat, long, height
		Phi0 = phi0 ;
		Lam0 = lam0 ;
		H0 = h0;

		// Parameter of oscilation of flight path
		TPhi = tphi;
		TLam = tlam;
		TH = th;
		
		kPhi = kphi;
		kLam = klam;
		deltaPhi = deltaphi; 
		deltaLam = deltalam;
		deltaH = deltah;
		
		ddeltaPhi = ddeltaphi;
		ddeltaLam = ddeltalam;
		ddeltaH = ddeltah;
		
		WPhi = 2*Math.PI/TPhi;
		WLam = 2*Math.PI/TLam;
		WH = 2*Math.PI/TH;
		InitPathVars();
		t = loadTimeArray(simTime,stepTime);
	}
	
	
	
	/*
FlightPathGen(double[] time, double[] pathPos0, 
				  double[] pathTpos,double[] kPos, 
				  double[] deltaPos, double[] ddeltaPos ){
		simTime = time[0]; 
		// Step time, s
		stepTime = time[1]; 
		stepCount = (int) (simTime/stepTime);
		
		// Parameters of motion of aircraft
		// Start point on surface of Earth, lat, long, height
		Phi0 = pathPos0[0]*(Math.PI/180) ;
		Lam0 = pathPos0[1]*(Math.PI/180) ;
		H0 = pathPos0[2];

		// Parameter of oscilation of flight path
		TPhi = pathTpos[0];
		TLam = pathTpos[1];
		TH = pathTpos[2];
		
		kPhi = kPos[0];
		kLam = kPos[1];
		deltaPhi = deltaPos[0]; 
		deltaLam = deltaPos[1];
		deltaH = deltaPos[2];
		
		ddeltaPhi = ddeltaPos[0];
		ddeltaLam = ddeltaPos[1];
		ddeltaH = ddeltaPos[2];
		
		WPhi = 2*Math.PI/TPhi;
		WLam = 2*Math.PI/TLam;
		WH = 2*Math.PI/TH;
		InitPathVars();
		t = loadTimeArray(simTime,stepTime);
	*/
	


	void InitPathVars(){
		
		Phi = new double[t.length];
		Lam = new double[t.length];
		H = new double[t.length];
		dPhi = new double[t.length];
		dLam = new double[t.length];
		dH = new double[t.length];	
		ddPhi = new double[t.length];
		ddLam = new double[t.length];
		ddH = new double[t.length];	
		R1 = new double[t.length];	
		R2 = new double[t.length];	
		dR1 = new double[t.length];	
		dR2 = new double[t.length];	
		VE = new double[t.length];
		VN = new double[t.length];
		VH = new double[t.length];
		VR = new double[t.length];
		dVE = new double[t.length];
		dVN = new double[t.length];
		dVH = new double[t.length];
		AE = new double[t.length];
		AN = new double[t.length];
		AH = new double[t.length];
		q = new double[t.length];
		g = new double[t.length];
		Pitch = new double[t.length];
		Yaw = new double[t.length];
		Roll = new double[t.length];
		
	}
	
	static double[] loadTimeArray(double simT, double stepT){
		int stepCount = (int) (simT/stepT);
		double[] Time = new double[stepCount];
		for (int i=0; i<stepCount; i++){
			Time[i] = i*stepT; 
		}
		return Time;
	}
	
	void ComputePhiLamH (){
		/* phi = phi0 + Kphi*t +delta_phi*sin(w_phi*t + ddelta_phi);
		 * lam = lam0 + Klam*t +delta_lam*sin(w_lam*t + ddelta_lam);
		 * h = h0 - delta_h0*cos(w_h*t+ddelta_h);
		 * dphi =  Kphi + delta_phi*w_phi*cos(w_phi*t + ddelta_phi);
		 * dlam =  Klam + delta_lam*w_lam*cos(w_lam*t + ddelta_lam);
		 * dh = delta_h0*w_h*sin(w_h*t+ddelta_h);
		 * ddphi =  - delta_phi*(w_phi^2)*sin(w_phi*t + ddelta_phi);
		 * ddlam =  - delta_lam*(w_lam^2)*sin(w_lam*t + ddelta_lam);
		 * ddh = delta_h0*(w_h^2)*cos(w_h*t+ddelta_h);
		 * */
		WPhi = 2*Math.PI/TPhi;
		WLam = 2*Math.PI/TLam;
		WH = 2*Math.PI/TH;
		
		for (int i=0; i<t.length; i++){
			Phi[i] =  Phi0 + kPhi*t[i] +deltaPhi*Math.sin(WPhi*t[i] + ddeltaPhi);	
			Lam[i] =  Lam0 + kLam*t[i] +deltaLam*Math.sin(WLam*t[i] + ddeltaLam);	
			H[i] = H0 - deltaH*Math.cos(WH*t[i] + ddeltaH);
			
			dPhi[i] =  kPhi + deltaPhi*WPhi*Math.cos(WPhi*t[i] + ddeltaPhi);	
			dLam[i] =  kLam + deltaLam*WLam*Math.cos(WLam*t[i] + ddeltaLam);		
			dH[i] =  deltaH*WH*Math.sin(WH*t[i] + ddeltaH);
			
			ddPhi[i] = - deltaPhi*(Math.pow(WPhi,2))*Math.sin(WPhi*t[i] + ddeltaPhi);	
			ddLam[i] =  - deltaLam*(Math.pow(WLam,2))*Math.sin(WLam*t[i] + ddeltaLam);			
			ddH[i] =  deltaH*(Math.pow(WH, 2)*Math.cos(WH*t[i] + ddeltaH));			
			
		}
	}
	void ComputeR1R2(){
		/* a = 6378137; % m
		 * e2 =  6.66943799901413*10^-3;
		 * R1 = a./(1-(e2)*sin(phi).^2).^0.5;
		 * R2 = R1.*((1-e2)./(1-e2*(sin(phi).^2)));
		 * dR1 = (a*e2*sin(phi).*cos(phi).*dphi)./(1-e2*sin(phi).^2).^1.5;
		 * dR2 = dR1.*((1-e2)./(1-e2*sin(phi).^2)) + ...
		 * R1.*((1-e2)*2*e2.*sin(phi).*cos(phi).*dphi)./(1-e2.*sin(phi).^2).^2;
 		 * */
		for (int i=0; i<t.length; i++){
			R1[i] = EARTH_RADIUS/Math.sqrt(1-E2*Math.pow(Math.sin(Phi[i]),2));
			R2[i] = (R1[i]*(1-E2))/(1-E2*Math.pow(Math.sin(Phi[i]),2));
			dR1[i] = (EARTH_RADIUS*E2*Math.sin(Phi[i])*Math.cos(Phi[i])*dPhi[i])/Math.pow(1-E2*Math.pow(Math.sin(Phi[i]),2),1.5);
			dR2[i] = dR1[i]*((1-E2)/(1-E2*Math.pow(Math.sin(Phi[i]),2))) + R1[i]*((1-E2)*2*E2*Math.sin(Phi[i])*Math.cos(Phi[i])*dPhi[i])/Math.pow(1-E2*Math.pow(Math.sin(Phi[i]),2),2);
			
		}
	}
	void ComputeVenhr(){
		/*
		 * V_N = dphi.*(R2 +h);
		 * V_E = dlam.*(R1 +h).*cos(phi);
		 * V_h = dh;

		 * dV_N = ddphi.*(R2 + h) + dphi.*(dR2 + dh);
		 * dV_E = ddlam.*(R1 + h).*cos(phi) + dlam.*(dR1 + dh).*cos(phi)-...
		 * dlam.*(R1 + h).*sin(phi).*dphi;
		 * dV_h = ddh;
		q = dlam + 2*wz;
		g = get_g(phi,h);
		*/
		
		for (int i=0; i<t.length; i++){
			VN[i] = dPhi[i]*(R2[i] +H[i]);
			VE[i] = dLam[i]*(R1[i] +H[i])*Math.cos(Phi[i]);
			VH[i]= dH[i];
			dVN[i] = ddPhi[i]*(R2[i] + H[i]) + dPhi[i]*(dR2[i] + dH[i]);
			dVE[i] = ddLam[i]*(R1[i] + H[i])*Math.cos(Phi[i]) + dLam[i]*(dR1[i] + dH[i])*Math.cos(Phi[i]) - dLam[i]*(R1[i] + H[i])*Math.sin(Phi[i])*dPhi[i];
			dVH[i] = ddH[i];
			VR[i] = Math.sqrt(Math.pow(VE[i], 2) + Math.pow(VN[i], 2));
		}
	}
	void ComputeAenh(){
		/*
		 * q = dlam + 2*wz;
		 * g = get_g(phi,h);
		 * a_N = dV_N + q.*sin(phi).*V_E + dphi.*V_h;
		 * a_E = dV_E - q.*sin(phi).*V_N+q.*cos(phi).*V_h;
		 * a_h = dV_h - q.*cos(phi).*V_E - dphi.*V_N + g;
		 */

		for (int i=0; i<t.length; i++){
			
			 q[i] = dLam[i] + 2*EARTH_SPEED;
			 g[i] = (MIU/Math.pow(EARTH_RADIUS,2))*(1 - 2*(H[i]/EARTH_RADIUS)+0.75*E2*Math.pow(Math.sin(Phi[i]),2));
			 
			 AE[i] = dVE[i] - q[i]*Math.sin(Phi[i])*VN[i]+q[i]*Math.cos(Phi[i])*VH[i]; 
			 AN[i] = dVN[i] + q[i]*Math.sin(Phi[i])*VE[i] + dPhi[i]*VH[i];
			 AH[i] = dVH[i] - q[i]*Math.cos(Phi[i])*VE[i] - dPhi[i]*VN[i] + g[i];
		}
	}
	void ComputePRY(){
		/*
		* pitch = atan2(V_h,V_r);
		* yaw = atan2(V_E,V_N);
		* Kg = 0.1; % rad/(m/s^2)
		* roll = Kg*(V_N.*dV_E - V_E.*dV_N)./(V_r.*cos(pitch));
		* pitch = atan2(V_h,V_r);*/
		for (int i=0; i<t.length; i++){
			Pitch[i] = Math.atan2(VH[i],VR[i]);
			Yaw[i] = Math.atan2(VE[i],VN[i]);
			double Kg = 0.1; // rad/(m/s^2)
			Roll[i] = Kg*(VN[i]*dVE[i] - VE[i]*dVN[i])/(VR[i]*Math.cos(Pitch[i]));
			}
	}
	
}
