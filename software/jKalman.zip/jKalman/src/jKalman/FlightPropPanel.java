package jKalman;

import java.awt.*;

import javax.swing.*;

public class FlightPropPanel extends JPanel {
	
	JTextField TextfieldTime;
	JTextField TextfieldStepTme;
	
	JTextField TextfieldPhi0;
	JTextField TextfieldLam0;
	JTextField TextfieldH0;
	
	JTextField TextfieldTPhi;
	JTextField TextfieldTLam;
	JTextField TextfieldTH;
	
	JTextField TextfieldDeltaPhi;
	JTextField TextfieldDeltaLam;
	JTextField TextfieldDeltaH;
	
	JTextField TextfieldDdeltaPhi;
	JTextField TextfieldDdeltaLam;
	JTextField TextfieldDdeltaH;
	
	JTextField TextfieldKPhi;
	JTextField TextfieldKLam;
	JButton ButtonCalc;
	
	
	
	
	/** Constructor builds panel with labels and text fields. **/
	FlightPropPanel(double [] ParamData) {
		
		
		
		TextfieldTime = new JTextField(String.valueOf(ParamData[0]));
		TextfieldStepTme = new JTextField(String.valueOf(ParamData[1]));
		
		TextfieldPhi0 = new JTextField(String.valueOf(ParamData[2]));
		TextfieldLam0 = new JTextField(String.valueOf(ParamData[3]));
		TextfieldH0 = new JTextField(String.valueOf(ParamData[4]));
		
		TextfieldTPhi = new JTextField(String.valueOf(ParamData[5]));
		TextfieldTLam = new JTextField(String.valueOf(ParamData[6]));
		TextfieldTH = new JTextField(String.valueOf(ParamData[7]));
		
		TextfieldDeltaPhi = new JTextField(String.valueOf(ParamData[8]));
		TextfieldDeltaLam = new JTextField(String.valueOf(ParamData[9]));
		TextfieldDeltaH = new JTextField(String.valueOf(ParamData[10]));
		
		TextfieldDdeltaPhi = new JTextField(String.valueOf(ParamData[11]));
		TextfieldDdeltaLam = new JTextField(String.valueOf(ParamData[12]));
		TextfieldDdeltaH = new JTextField(String.valueOf(ParamData[13]));
		
		TextfieldKPhi = new JTextField(String.valueOf(ParamData[14]));
		TextfieldKLam = new JTextField(String.valueOf(ParamData[15]));
		
		JLabel label_Time = new JLabel("time,s", SwingConstants.LEFT);
		JLabel label_StepTme = new JLabel("StepTme,s", SwingConstants.LEFT);
		
		JLabel label_Phi0 = new JLabel("Phi0,DEG", SwingConstants.LEFT);
		JLabel label_Lam0 = new JLabel("Lam0,DEG", SwingConstants.LEFT);
		JLabel label_H0 = new JLabel("H0,m", SwingConstants.LEFT);
		
		JLabel label_TPhi = new JLabel("TPhi", SwingConstants.LEFT);
		JLabel label_TLam = new JLabel("TLam", SwingConstants.LEFT);
		JLabel label_TH = new JLabel("TH", SwingConstants.LEFT);
		
		JLabel label_DeltaPhi = new JLabel("DeltaPhi", SwingConstants.LEFT);
		JLabel label_DeltaLam = new JLabel("DeltaLam", SwingConstants.LEFT);
		JLabel label_DeltaH = new JLabel("DeltaH", SwingConstants.LEFT);
		
		JLabel label_DdeltaPhi = new JLabel("DdeltaPhi", SwingConstants.LEFT);
		JLabel label_DdeltaLam = new JLabel("DdeltaLam", SwingConstants.LEFT);
		JLabel label_DdeltaH = new JLabel("DdeltaH", SwingConstants.LEFT);
		
		JLabel label_KPhi = new JLabel("KPhi", SwingConstants.LEFT);
		JLabel label_KLam = new JLabel("KLam", SwingConstants.LEFT);
		// Set the layout with 16 rows by 2 columns
		setLayout(new GridLayout(30, 2));

		//ButtonCalc = new JButton("Calculate");

		


		
		
		
		// Create the first label and right justify the text
		//JLabel label_top = new JLabel(label_str_top, SwingConstants.LEFT);

		// Insert the label and textfield into the top grid row
		add(TextfieldTime);	add(label_Time);
		add(TextfieldStepTme);	add(label_StepTme);
		add(TextfieldPhi0);	add(label_Phi0);
		add(TextfieldLam0);	add(label_Lam0);
		add(TextfieldH0);	add(label_H0);
		add(TextfieldTPhi);	add(label_TPhi);
		add(TextfieldTLam);	add(label_TLam);
		add(TextfieldTH);	add(label_TH);
		add(TextfieldDeltaPhi);	add(label_DeltaPhi);
		add(TextfieldDeltaLam);	add(label_DeltaLam);
		add(TextfieldDeltaH);	add(label_DeltaH);
		add(TextfieldDdeltaPhi);	add(label_DdeltaPhi);
		add(TextfieldDdeltaLam);	add(label_DdeltaLam);
		add(TextfieldDdeltaH);	add(label_DdeltaH);
		add(TextfieldKPhi);	add(label_KPhi);
		add(TextfieldKLam);	add(label_KLam);
		//add(ButtonCalc);
		
		

	} 

}// class InputsPanel
